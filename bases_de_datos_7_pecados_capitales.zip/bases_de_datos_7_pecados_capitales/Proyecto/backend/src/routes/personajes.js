const express = require('express');
const Bikes = require('../models/shpersonajes');
const sacros = require('../models/shcaballeros');
const parejas = require('../models/shparejas');
const router = express.Router();

const personaje = require('../models/shpersonajes');
const Caballeros = require('../models/shcaballeros');
const pareja = require('../models/shparejas');

router.get('/characters/add-character', (req, res) => {
    res.render('characters/new-character')
});

router.post('/characters/new-character', async (req, res) => {
    const {
        Name,
        poder,
        peleas
    } = req.body;
    const errors = [];

    if (!Name) {
        errors.push({
            text: '  inserte el nombre del personaje'
        });
    }
    if (!poder) {
        errors.push({
            text: 'inserte el poder del personaje'
        });
    }
    if (!peleas) {
        errors.push({
            text: ' inserte la pelea del personaje'
        });
    }
    if (errors.length > 0) {
        res.render('characters/new-character', {
            errors,
            Name,
            poder,
            peleas
        });
    } else {
        const newPersonaje = new personaje({
            Name,
            poder,
            peleas
        });
        await newPersonaje.save();
        res.redirect('/character')
    }

});
router.get('/character', async (req, res) => {
    await personaje.find()
        .sort({
            personaje: 'desc'
        })
        .then(documentos => {
            const contexto = {
                personaje: documentos.map(documento => {
                    return {
                        Name: documento.Name,
                        poder: documento.poder,
                        peleas: documento.peleas
                    }
                })
            }
            res.render('characters/all-characters', {
                personaje: contexto.personaje
            })
        })



})
//---------caballeros sacros-----------------------------------
router.get('/characters/add-sacros', (req, res) => {
    res.render('characters/new-sacros')
});

router.post('/characters/new-sacros', async (req, res) => {
    const {
        Name,
        poder

    } = req.body;
    const errors = [];

    if (!Name) {
        errors.push({
            text: '  inserte el nombre del personaje'
        });
    }
    if (!poder) {
        errors.push({
            text: 'inserte el poder del personaje'
        });
    }

    if (errors.length > 0) {
        res.render('characters/new-character', {
            errors,
            Name,
            poder,
            peleas
        });
    } else {
        const newBike = new Caballeros({
            Name,
            poder


        });

        await newBike.save();
        res.redirect('/sacros')
    }

});

router.get('/sacros', async (req, res) => {
    await Caballeros.find()
        .sort({
            sacros: 'desc'
        })
        .then(documentos => {
            const contexto = {
                sacros: documentos.map(documento => {
                    return {
                        Name: documento.Name,
                        poder: documento.poder,

                    }
                })
            }
            res.render('characters/all-sacros', {
                sacros: contexto.sacros
            })
        })



})
//----------parejas--------------------------------------------------------
router.get('/characters/add-parejas', (req, res) => {
    res.render('characters/new-parejas')
});

router.post('/characters/new-parejas', async (req, res) => {
    const {
        Name,


    } = req.body;
    const errors = [];

    if (!Name) {
        errors.push({
            text: '  inserte el nombre de la pareja'
        });
    }
    if (errors.length > 0) {
        res.render('characters/new-parejas', {
            errors,
            Name,

        });
    } else {
        const newBike = new pareja({
            Name,


        });

        await newBike.save();
        res.redirect('/parejas')
    }

});

router.get('/parejas', async (req, res) => {
    await pareja.find()
        .sort({
            pairs: 'desc'
        })
        .then(documentos => {
            const contexto = {
                pairs: documentos.map(documento => {
                    return {
                        Name: documento.Name,


                    }
                })
            }
            res.render('characters/all-parejas', {
                pairs: contexto.pairs
            })
        })
})


// ------------imagenes-------------------------
router.get('/characters/add-img', (req, res) => {
    res.render('characters/img')
});

router.post('/characters/img', async (req, res) => {
    const {
        Name,


    } = req.body;
    const errors = [];

    if (!Name) {
        errors.push({
            text: '  inserte el nombre de la pareja'
        });
    }
    if (errors.length > 0) {
        res.render('characters/new-parejas', {
            errors,
            Name,

        });
    } else {
        const newBike = new pareja({
            Name,


        });

        await newBike.save();
        res.redirect('/parejas')
    }

});

router.get('/parejas', async (req, res) => {
    await pareja.find()
        .sort({
            pairs: 'desc'
        })
        .then(documentos => {
            const contexto = {
                pairs: documentos.map(documento => {
                    return {
                        Name: documento.Name,


                    }
                })
            }
            res.render('characters/all-parejas', {
                pairs: contexto.pairs
            })
        })
})





module.exports = router;