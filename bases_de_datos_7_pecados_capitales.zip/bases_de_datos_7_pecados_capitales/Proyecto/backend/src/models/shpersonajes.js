const mongoose = require('mongoose');
const {
    Schema
} = mongoose;

const personajesSchema = new Schema({
    Name: {
        type: String,
        required: true
    },
    poder: {
        type: String,
        required: true
    },
    peleas: {
        type: String,
        required: true
    },
    

});

module.exports = mongoose.model('personajes', personajesSchema)