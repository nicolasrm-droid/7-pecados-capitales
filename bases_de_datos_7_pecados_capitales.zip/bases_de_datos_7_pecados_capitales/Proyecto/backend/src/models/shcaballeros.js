const mongoose = require('mongoose');
const {
    Schema
} = mongoose;

const caballerosSchema = new Schema({
    Name: {
        type: String,
        required: true
    },
    poder: {
        type: String,
        required: true
    },
    

});

module.exports = mongoose.model('caballeros', caballerosSchema)