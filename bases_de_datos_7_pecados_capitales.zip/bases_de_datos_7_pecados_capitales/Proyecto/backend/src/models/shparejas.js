const mongoose = require('mongoose');
const {
    Schema
} = mongoose;

const parejasSchema = new Schema({
    Name: {
        type: String,
        required: true
    }
    

});

module.exports = mongoose.model('parejas', parejasSchema)